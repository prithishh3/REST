import vtk
import pyvista as pv
import numpy as np
import threading
import time
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('material_1.vtr')
mesh4 = pv.read('space_1.vtr')
drags = dict(show_edges=False)

f=open("dipoles.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	print(x,y)
	

x1 = float(x)
y1 = float(y)

pack_density = y1/x1

g = float("{:.3f}".format(pack_density))

print(g)
#result.append(lines.split(' ')[1])

f=open("input.txt")

lines=f.readlines()

for z in lines:
	result=z.split(" ")
	
	r = result[0]

	
#	print(a,b,c)
	
r1 = int(r)

contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()
contours4 = mesh4.contour()


inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(2.0, invert=True)

pv.set_plot_theme("dark")
p = pv.Plotter(shape=(1,3), window_size=[1800,800], title="3D Plot (Strongly Damaged Sphere: default seeds)", off_screen=True)


p.subplot(0,0)
#p.add_mesh(mesh, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours, color="white", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Initial Structure\nNo. of dipoles ='+x, font='times', shadow=True, color='black')
p.add_text('Diameter ='+str(r1), 'lower_left', font='times', shadow=True)


p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.subplot(0,1)
#p.add_mesh(mesh, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(contours, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(contours3, style="surface", opacity=0.5, render_points_as_spheres=False, color="red", specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_mesh(contours4, style="surface", opacity=0.5, render_points_as_spheres=False, color="black", specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_text('Distribution of Seed points', font='times', shadow=True, color='black')
p.add_text('Material seeds \nSpace seeds', 'lower_left', font='times', font_size=12, shadow=True)
p.add_text('(red) \n (black)', 'lower_edge', font='times', font_size=12, shadow=True)
p.add_text('=21'+'\n=20', 'lower_right', font='times', font_size=12, shadow=True)



p.subplot(0,2)
#p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
p.add_mesh(contours2, color="white", line_width=2.0, opacity=1.0, specular=1.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)

p.add_text('Final Structure\nNo. of dipoles ='+y, font='times', shadow=True, color='black')
p.add_text('Packing fraction ='+str(g), 'lower_right', font='times', shadow=True)
#p.add_text('No. of dipoles ='+y, 'upper_right')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.set_background("grey", top="lightskyblue")
p.view_isometric()
p.view_yz()
#p.save_graphic('plot.svg')
p.screenshot('plot.png')
p.close()

