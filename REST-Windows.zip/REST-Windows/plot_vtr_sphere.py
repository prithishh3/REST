import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
drags = dict(show_edges=False)

contours = mesh.contour()


inside1 = contours2.threshold(0.0)


pv.set_plot_theme("night")
p = pv.Plotter(shape=(1,1), window_size=[900,900])


p.subplot(0,0)
p.add_mesh(mesh, color="white", specular=5.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours, color="silver", line_width=0.1, opacity=0.0, use_transparency=True, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Initial Structure')
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='white')

p.set_background("navy", top="royalblue")
p.view_isometric()
p.show(screenshot='plot_initial.png')

