#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_superellipsoid.out isphere
wait $!
./vtrconvert final_material_a.out fma
wait $!
./vtrconvert final_material_b.out fmb
wait $!
./vtrconvert $(awk -F ' ' '{print $5}' input.txt) rsphere
wait $!
