gfortran ps_inh_material1.f90 -o ps_inhm1
./ps_inhm1
wait $!
gfortran ps_inh_material2.f90 -o ps_inhm2
./ps_inhm2
wait $!
gfortran ps_inh_mix.f90 -o ps_mix
./ps_mix
wait $!
