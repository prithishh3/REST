#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert $(awk -F ' ' '{print $5}' input.txt) rsphere
wait $!
./vtrconvert rs_material1.out material
wait $!
./vtrconvert rs_space1.out space
wait $!
