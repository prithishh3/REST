#!/bin/bash
echo "Calculation started ..."
gfortran core1.f90 -o cs1
./cs1
wait $!

