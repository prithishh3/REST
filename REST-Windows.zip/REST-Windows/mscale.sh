gfortran agg_center.f90 -o agg_center
./agg_center
wait $!
