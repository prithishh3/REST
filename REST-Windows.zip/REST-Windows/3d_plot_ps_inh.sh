#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert final_material_a.out fma
wait $!
./vtrconvert final_material_b.out fmb
wait $!
./vtrconvert $(awk -F ' ' '{print $7}' input.txt) rsphere
wait $!

