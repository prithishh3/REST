./calltarget <shp64x64x64.dat
awk 'NR>='8 target.out > target_mod.out