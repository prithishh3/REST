#!/bin/bash
xterm -e java -jar REST1.jar &
