import vtk
import pyvista as pv
import numpy as np
#mesh = pv.read('isphere_1.vtr')
mesh = pv.read('rsphere_1.vtr')
drags = dict(show_edges=False)

#result.append(lines.split(' ')[1])

f=open("input.txt")

lines=f.readlines()

for z in lines:
	result=z.split(" ")
	
	#r = result[0]
	m_1 = result[0]
	m_2 = result[2]

	
	#print(r,m,s)
	
#r1 = int(r)*2
m1 = int(m_1)
m2 = int(m_2)

contours = mesh.contour()
#contours2 = mesh2.contour()

#inside1 = contours2.threshold(0.0)
inside = contours.threshold(0.0)

pv.set_plot_theme("night")
p = pv.Plotter(window_size=[800,800], title="3D Plot")


p.add_mesh(mesh, color="White", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=5.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)
p.add_mesh(contours, style="surface", render_points_as_spheres=False, color=None, scalars=None, clim=contours.get_data_range(), line_width=0.5, opacity=0.3, specular=5.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=False)

p.add_text('Core-shell Structure', font='times', shadow=True, color='black')
p.add_text('Core Radius = '+str(m2)+'\nShell Radius = '+str(m1), position='lower_left', font='times', shadow=True, color='white')

#p.add_text('No. of dipoles ='+y, 'upper_right')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.set_background("grey", top="lightskyblue")
p.view_isometric()
p.show(screenshot='plot.png')

