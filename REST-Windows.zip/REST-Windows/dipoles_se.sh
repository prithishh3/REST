#!/bin/bash
echo "$(cat ellipsoid.dat | wc -l) $(cat target_final.out | wc -l)" > dipoles_se.in  
