#!/bin/bash
echo "Calculation started ..."
gfortran core2.f90 -o cs2
./cs2
wait $!

