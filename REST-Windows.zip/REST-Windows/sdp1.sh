#!bin/bash
./calltarget < shp*.dat
