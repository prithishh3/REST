#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert $(awk -F ' ' '{print $4}' input.txt) rsphere
wait $!
./vtrconvert sdp_material_c1.out material
wait $!
./vtrconvert sdp_space_c1.out space
wait $!

