#!/bin/bash
echo " "
read -n 3 -p "Enter the initial radius of the sphere (in number of dipoles): " RADIUS
declare -i D=$RADIUS*2
var='shp'$D'x'$D'x'$D'.dat'
echo "ELLIPSOID" >>$var
echo "$D $D $D" >>$var
echo "0 0 0" >>$var
./calltarget < $var
wait $!
read -n 8 -p "Enter the number of dipoles: " DIPOLES
read -n 70 -p "Enter the name of output file (within 70 characters): " FILE_NAME
echo " "
echo "$DIPOLES $D $FILE_NAME" > input.txt 
declare -i A=8
declare -i B=$DIPOLES+$A
cp target.out initial_sphere.out
awk 'NR>='$A target.out > target_mod.out
echo gfortran sdp_material.f90 -o sdp_m
gfortran sdp_material.f90 -o sdp_m
wait $!
echo ./sdp_m
./sdp_m
wait $!
echo gfortran sdp_space.f90 -o sdp_s
gfortran sdp_space.f90 -o sdp_s
wait $!
echo ./sdp_s
./sdp_s
wait $!
echo gfortran sdp_final.f90 -o sdp_f
gfortran sdp_final.f90 -o sdp_f
wait $!
echo ./sdp_f
./sdp_f
wait $!
chmod +x vtrconvert
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert $FILE_NAME rsphere
wait$!
mv $FILE_NAME dda_target/
rm $var
python3 plot_vtr.py
