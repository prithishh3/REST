#!/bin/bash
declare -i SHPAR1=$(awk -F ' ' '{print $1}' shapepar.in)*2
declare -i SHPAR2=$(awk -F ' ' '{print $2}' shapepar.in)*2
declare -i SHPAR3=$(awk -F ' ' '{print $3}' shapepar.in)*2
declare -i e=$(awk -F ' ' '{print $4}' shapepar.in)
declare -i n=$(awk -F ' ' '{print $5}' shapepar.in)
vare='elp'$SHPAR1'x'$SHPAR2'x'$SHPAR3'.dat'
echo "SUPELLIPS" >>$vare
echo "$SHPAR1 $SHPAR2 $SHPAR3 $e $n" >>$vare
echo "0 0 0 0 0" >>$vare
./calltarget < $vare
cp target.out target_ellipsoid.out
wait $!
cp target.out initial_superellipsoid.out
awk 'NR>='8 target.out > ellipsoid.dat
wait $!
if [ "$SHPAR1" -eq "$SHPAR2" ] && [ "$SHPAR2" -eq "$SHPAR3" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR1'x'$SHPAR1'x'$SHPAR1'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR1 $SHPAR1 $SHPAR1" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR1" -gt "$SHPAR2" ] && [ "$SHPAR1" -gt "$SHPAR3" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR1'x'$SHPAR1'x'$SHPAR1'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR1 $SHPAR1 $SHPAR1" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat	
elif [ "$SHPAR2" -gt "$SHPAR1" ] && [ "$SHPAR2" -gt "$SHPAR3" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR2'x'$SHPAR2'x'$SHPAR2'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR2 $SHPAR2 $SHPAR2" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR3" -gt "$SHPAR1" ] && [ "$SHPAR3" -gt "$SHPAR2" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR3'x'$SHPAR3'x'$SHPAR3'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR3 $SHPAR3 $SHPAR3" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR1" -eq "$SHPAR2" ] && [ "$SHPAR1" -gt "$SHPAR3" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR1'x'$SHPAR1'x'$SHPAR1'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR1 $SHPAR1 $SHPAR1" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR1" -eq "$SHPAR2" ] && [ "$SHPAR3" -gt "$SHPAR1" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR3'x'$SHPAR3'x'$SHPAR3'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR3 $SHPAR3 $SHPAR3" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR2" -eq "$SHPAR3" ] && [ "$SHPAR2" -gt "$SHPAR1" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR2'x'$SHPAR2'x'$SHPAR2'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR2 $SHPAR2 $SHPAR2" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR2" -eq "$SHPAR3" ] && [ "$SHPAR1" -gt "$SHPAR2" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR1'x'$SHPAR1'x'$SHPAR1'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR1 $SHPAR1 $SHPAR1" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR3" -eq "$SHPAR1" ] && [ "$SHPAR3" -gt "$SHPAR2" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR3'x'$SHPAR3'x'$SHPAR3'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR3 $SHPAR3 $SHPAR3" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
elif [ "$SHPAR3" -eq "$SHPAR1" ] && [ "$SHPAR2" -gt "$SHPAR3" ]
then
	echo "==== Creating circumscribing sphere ====="
	declare -i D=$SHAPR1
	var='shp'$SHPAR2'x'$SHPAR2'x'$SHPAR2'.dat'
	echo "ELLIPSOID" >>$var
	echo "$SHPAR2 $SHPAR2 $SHPAR2" >>$var
	echo "0 0 0" >>$var
	./calltarget < $var
	wait $!
	awk 'NR>='8 target.out > circum_sphr.dat
fi
wait $!
echo "========== Generating Surface Space Seeds =======" 
gfortran supellips_rs_space.f90 -o srs_s
./srs_s
wait $!
echo "============ Generating Material Seeds =========="
gfortran supellips_rs_material.f90 -o srs_m
./srs_m
wait $!
echo "============ Generating Final Structure ========="
gfortran supellips_rs_final.f90 -o srs_f
./srs_f
wait $!

