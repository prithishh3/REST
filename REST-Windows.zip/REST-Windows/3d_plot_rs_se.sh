#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_superellipsoid.out isphere
wait $!
./vtrconvert $(awk -F ' ' '{print $3}' input.txt) rsphere
wait $!
./vtrconvert se_rs_material1.out material
wait $!
./vtrconvert se_rs_space1.out space
wait $!

