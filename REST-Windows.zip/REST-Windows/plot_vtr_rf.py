import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('material_1.vtr')
mesh4 = pv.read('space_1.vtr')
mesh5 = pv.read('agg_1.vtr')
drags = dict(show_edges=False)

f=open("dipoles_rf.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	z = result[2]
	l = result[3]
	print(x,y,z,l)
	

x1 = float(x)
y1 = float(y)
z1 = float(z)
l1 = float(l)

pack_density_agg = y1/x1
pack_density_final = z1/x1

porosity_agg = (x1-y1)/x1
porosity_final = (x1-z1)/x1

vol_rough_p = porosity_final - porosity_agg
vol_rough = l1/y1

error_rogh_vol = (vol_rough_p-vol_rough)*100

h = float("{:.3f}".format(pack_density_agg))
g = float("{:.3f}".format(pack_density_final))

por_agg = float("{:.3f}".format(porosity_agg))
por_final = float("{:.3f}".format(porosity_final))


vrp = float("{:.3f}".format(vol_rough_p))
vr = float("{:.3f}".format(vol_rough))



er = float("{:.3f}".format(error_rogh_vol))


f1=open("rms.txt")

lines= f1.readlines()

for i in lines:
	resultrms=i.split(" ")
	
	j = resultrms[1]
	k = resultrms[2]
	l = resultrms[3]
	print(j,k,l)
	
	


print(g)
#result.append(lines.split(' ')[1])

f=open("input.txt")

lines=f.readlines()

for u in lines:
	result=u.split(" ")
	
	r = result[0]
	m = result[1]
	s = result[2]

	
	#print(r,m,s)
	
r1 = int(r)*2
m1 = int(m)
s1 = int(s)

#q = float("{:.3f}".format(m1/m2))

contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()
contours4 = mesh4.contour()
contours5 = mesh5.contour()

#surf_elv= contours2.elevation()
#type(surf)

#contours2.plot(line_width=5)

inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(2.0, invert=True)


pv.set_plot_theme("night")
p = pv.Plotter(shape=(1,3), window_size=[1800,800], title="3D Plot (REST)")


p.subplot(0,0)
#p.add_mesh(mesh, color="white", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
p.add_mesh(contours, color="white", opacity=0.01, show_scalar_bar=False, specular=5.0, lighting=True, render=True, smooth_shading=True)
#p.add_mesh(mesh5, color="snow", specular=5.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours5, color="white", line_width=0.1, opacity=0.0, use_transparency=True, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=True, lighting=True, render=True, ambient=0.0)

p.add_text('Sphere Aggregate Combined Plot', 'upper_right', font='times', font_size=12, shadow=True, color="black")

p.add_text('Initial Structure\nNo. of dipoles ='+x+'\n\nInitial Aggregate Structure\nNo. of dipoles ='+y, font='times', font_size=12, shadow=True, color="black")

p.add_text('Porosity ='+str(por_agg)+'\nEqui-vol. sphere diameter ='+str(r1), 'lower_left', font='times', font_size=15, shadow=True, color="white")
#p.add_text('Initial Aggregate Structure\nNo. of dipoles ='+y, font='times', shadow=True, color="black")


p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.subplot(0,1)
#p.add_mesh(mesh5, color="white", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
p.add_mesh(contours5, color="white", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True, smooth_shading=True)
#p.add_mesh(contours5, style="surface", color=None, scalars=None, clim=[0.0,1.0], line_width=0.0, opacity=0.3, specular=5.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=True)
p.add_mesh(contours3, style="surface", opacity=0.8, render_points_as_spheres=True, color="red", specular=5.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_mesh(contours4, style="surface", opacity=0.5, render_points_as_spheres=True, color="black", specular=5.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
#p.add_mesh(contours5, style="surface", opacity=0.8, render_points_as_spheres=True, color="yellow", specular=5.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_text('Distribution of seed points', 'upper_edge', font='times',font_size=12, shadow=True, color="black")
#p.add_text('Material seeds = Red\nSurface Space seeds = black', 'lower_left', font='times', font_size=10, shadow=False, color="yellow")

p.add_text('Material seeds \nSpace seeds', 'lower_left', font='times', font_size=10, shadow=True, color='white')
p.add_text('(red) \n (black)', 'lower_edge', font='times', font_size=10, shadow=True, color='white')
p.add_text('='+str(m1)+'\n='+str(s1), 'lower_right', font='times', font_size=10, shadow=True, color='white')


#p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.subplot(0,2)
#p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
p.add_mesh(contours, color="white", opacity=0.01, show_scalar_bar=False, specular=5.0, lighting=True, render=True, smooth_shading=True)
p.add_mesh(contours2, color="white", opacity=1.0, specular=2.0, show_edges=False, smooth_shading=True, lighting=True, render=True, show_scalar_bar=False)
#p.add_mesh(contours2, style="surface", color=None, scalars=None, clim=[0.0,1.0], line_width=0.0, opacity=0.3, specular=5.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=True)

p.add_text('Rough Fractal Aggrgegate', 'upper_right', font='times',font_size=12, shadow=True, color="black")
p.add_text('Final Structure\nNo. of dipoles ='+z, font='times', font_size=12, shadow=True, color="black")
p.add_text('Porosity ='+str(por_final)+'\n'+'Roughnes(rms) ='+str(j), 'lower_right', font='times', font_size=12, shadow=True, color="white")
#p.add_text('Roughnes(rms) ='+str(j)+'\nMax. Roughness(rms) ='+str(k)+'\nMin. Roughness(rms) ='+str(l)+'\n\n\n', 'lower_right', font='times', font_size=10, shadow=False, color="yellow")
#p.add_text('Volume of Roughness from porosity ='+str(vrp)+'\nVolume of Roughness from RMS ='+str(vr)+'\nError ='+str(er)+'%', 'lower_right', font='times', font_size=12, shadow=False, color="yellow")
#p.add_text('Error ='+str(er)+'%', 'lower_left', font='times', font_size=10, shadow=True, color="red")


#p.add_text('No. of dipoles ='+y, 'upper_right')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.set_background("grey", top="lightskyblue")
p.view_yz()
p.camera.zoom(1.1)
p.show(screenshot='plot.png')

