#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_superellipsoid.out isphere
wait $!
./vtrconvert $(awk -F ' ' '{print $4}' input.txt) rsphere
wait $!
./vtrconvert se_ps_material1.out material
wait $!
./vtrconvert se_ps_ispace1.out ispace
wait $!
./vtrconvert se_ps_sspace1.out sspace
wait $!

