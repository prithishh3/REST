#!/bin/bash
echo "Calculation started ..."
echo -ne '>                       [1%]\r'
gfortran rs_material.f90 -o rs_m
./rs_m
wait $!
echo -ne '>>>>>>>>>>              [40%]\r'
gfortran rs_space.f90 -o rs_s
./rs_s
wait $!
echo -ne '>>>>>>>>>>>>>>>>>       [80%]\r'
gfortran rs_final.f90 -o rs_f
./rs_f
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>[100%]\r'
