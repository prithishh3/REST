import vtk
import pyvista as pv
import numpy as np
import matplotlib.pyplot as plt
mesh2 = pv.read('rsphere_1.vtr')
drags = dict(show_edges=False)

f=open("dipoles.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	print(x,y)
	

x1 = float(x)
y1 = float(y)

pack_density = y1/x1

g = float("{:.3f}".format(pack_density))

print(g)
#result.append(lines.split(' ')[1])



contours2 = mesh2.contour()


inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(2.0, invert=True)

pv.set_plot_theme("global_theme")
p = pv.Plotter(window_size=[595,448], title="3D Plot (Strongly Damaged Sphere: custom seeds)")


#p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="white", line_width=2.0, opacity=1.0, specular=5.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)

p.add_mesh(contours2, color="white", line_width=2.0, opacity=1.0, specular=5.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)

p.add_text('Strongly Damaged Sphere', 'upper_edge', font='times', font_size=15, shadow=True, color='black')
#p.add_text('Packing fraction ='+str(g), 'lower_left', font='times', shadow=True)
#p.add_text('No. of dipoles ='+y, 'upper_right')

p.link_views()
#p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='white')

p.set_background("grey", top="lightskyblue")
p.view_yz()
p.camera.zoom(1.3)
p.show(screenshot='sds_1.png')
#p.save_graphic('3dplot.eps')

