#!/bin/bash
chmod +x vtrconvert
./vtrconvert $(awk -F ' ' '{print $3}' input.txt) rsphere
wait $!

