import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('rsphere1_1.vtr')
mesh4 = pv.read('rsphere2_1.vtr')

drags = dict(show_edges=False)

contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()
contours4 = mesh4.contour()


inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(0.25, invert=True)

#spheres = mesh.texture_map_to_sphere()
#dargs = dict(show_edges=True)

#glyph1 = mesh.glyph(geom=pv.Sphere(radius=0.1), factor=0.3, scale=False)
#glyph2 = mesh2.glyph(geom=pv.Sphere())

#glyph1 = contours.glyph(geom=pv.Sphere(radius=3.0))
#glyph2 = contours2.glyph(geom=pv.Sphere(radius=3.0))

pv.set_plot_theme("paraview")
p = pv.Plotter(shape=(2,2), window_size=[1080,1080])


p.subplot(0,0)
p.add_mesh(mesh, color="white", specular=5.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours, color="lightgrey", line_width=0.5, opacity=0.0, specular=5.0, use_transparency=True, show_edges=False, edge_color='teal', smooth_shading=True, lighting=True, render=True, ambient=0.0)
#p.add_mesh(glyph1, color="red")
#p.add_mesh(voxels, color=True, show_edges=True, opacity=0.5)
#p.add_mesh(glyph1)
p.add_text('Initial Structure')
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.subplot(0,1)
p.add_mesh(mesh2, color="White", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=5.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)
p.add_mesh(contours2, style="wireframe", render_points_as_spheres=True, color=None, scalars=None, clim=[1.0,2.0], line_width=1.0, opacity=0.5, specular=5.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=True)

#p.add_mesh(contours2, color=None, line_width=2.0, opacity=0.5, specular=5.0, show_edges=False, smooth_shading=True, lighting=True, render=True, show_scalar_bar=False)
#p.add_mesh(glyph2, color="red")
p.add_text('Final Structure')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.subplot(1,0)
p.add_mesh(mesh3, color="White", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=5.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)
p.add_mesh(contours3, style="wireframe", render_points_as_spheres=True, color=None, scalars=None, clim=[1.0,2.0], line_width=1.0, opacity=0.5, specular=5.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=True)

#p.add_mesh(contours2, color=None, line_width=2.0, opacity=0.5, specular=5.0, show_edges=False, smooth_shading=True, lighting=True, render=True, show_scalar_bar=False)
#p.add_mesh(glyph2, color="red")
p.add_text('Composite structure')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.subplot(1,1)
p.add_mesh(mesh4, color="White", opacity=0.1, show_scalar_bar=False, specular=5.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=5.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=5.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)
p.add_mesh(contours4, style="wireframe", render_points_as_spheres=True, color=None, scalars=None, clim=[1.0,2.0], line_width=1.0, opacity=0.5, specular=5.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=True)

#p.add_mesh(glyph2, color="red")
p.add_text('Composite Map')
#p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

#p.isometric_view_interactive()

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='white')

p.set_background("plum", top="royalblue")
p.view_isometric()
p.show(screenshot='plot.png')
#cpos = mesh.plot()
