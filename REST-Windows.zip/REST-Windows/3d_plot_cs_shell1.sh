#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert $(awk -F ' ' '{print $3}' input.txt) rsphere
wait $!
python3 plot_vtr_cs1.py
