import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('icomp1_1.vtr')

drags = dict(show_edges=False)

f=open("dipoles_se.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	print(x,y)
	

x1 = float(x)
y1 = float(y)

pack_density = y1/x1

g = float("{:.3f}".format(pack_density))

print(g)

contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()


inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(0.25, invert=True)

pv.set_plot_theme("dark")
p = pv.Plotter(shape=(2,2), window_size=[1080,1080], title="3D Plot")


p.subplot(0,0)
p.add_mesh(mesh, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours, color="lightgrey", line_width=0.5, opacity=0.0, specular=1.0, use_transparency=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Initial Structure\nNo. of dipoles ='+x, font='times', shadow=True)
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.subplot(0,1)
p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(inside1, opacity=0.0, color="purple", use_transparency=True, specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_text('Final Structure\nNo. of dipoles ='+y, font='times', shadow=True)
p.add_text('Packing density ='+str(g), 'lower_left', font='times', shadow=True)

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.subplot(1,0)
p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(contours, opacity=0.9, color="lightgrey", use_transparency=True, smooth_shading=True, specular=1.0, lighting=True, render=True, **drags, ambient=0.0)
p.add_mesh(inside1, opacity=0.0, color="purple", use_transparency=True, specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.0)

p.add_text('Composite structure', font='times', shadow=True)

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True)

p.subplot(1,1)
p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(contours3, style="surface", color=None, scalars=None, clim=[0.0,3.0], line_width=0.0, opacity=0.3, specular=1.0, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=False)

p.add_text('Composite Map', font='times', shadow=True)


p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='white')

p.set_background("plum", top="royalblue")
p.view_xz()
p.show()
