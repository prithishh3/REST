#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_superellipsoid.out isphere
wait $!
./vtrconvert tcomposites.out icomp1
wait $!
./vtrconvert $(awk -F ' ' '{print $3}' input.txt) rsphere
wait $!
