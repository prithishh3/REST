#!/bin/bash
echo "$(cat target_mod.out | wc -l) $(cat target_final.out | wc -l)" > dipoles.in
