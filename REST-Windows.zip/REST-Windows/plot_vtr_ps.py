import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('material_1.vtr')
mesh4 = pv.read('space_1.vtr')
mesh5 = pv.read('sspace_1.vtr')
drags = dict(show_edges=False)

f=open("dipoles.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	print(x,y)
	

x1 = float(x)
y1 = float(y)

pack_density = y1/x1

g = float("{:.3f}".format(pack_density))

print(g)
#result.append(lines.split(' ')[1])
f=open("input.txt")

lines=f.readlines()

for z in lines:
	result=z.split(" ")
	
	r = result[0]
	m = result[1]
	s = result[2]
	s_s = result[3]

	
	print(r,m,s,s_s)
	
r1 = int(r)*2
m1 = int(m)
s1 = int(s)
s_s1 = int(s_s)


contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()
contours4 = mesh4.contour()
contours5 = mesh5.contour()

inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(2.0, invert=True)

pv.set_plot_theme("dark")
p = pv.Plotter(shape=(1,3), window_size=[1800,800], title="3D Plot (REST)")


p.subplot(0,0)
#p.add_mesh(mesh, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours, color="white", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Initial Structure\nNo. of dipoles ='+x, font='times', shadow=True, color='black')
p.add_text('Diameter ='+str(r1), 'lower_left', font='times', shadow=True)

p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.subplot(0,1)
#p.add_mesh(mesh, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(contours, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.add_mesh(contours3, style="surface", opacity=0.8, render_points_as_spheres=True, color="red", specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_mesh(contours4, style="surface", opacity=0.5, render_points_as_spheres=True, color="black", specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_mesh(contours5, style="surface", opacity=0.8, render_points_as_spheres=True, color="darkgreen", specular=1.0, smooth_shading=False, lighting=True, render=True, **drags, ambient=0.1)
p.add_text('Distribution of Seed points', font='times', shadow=True, color='black')
#p.add_text('Material seeds = Red\nInternal Space seeds = Black\nSurface Space seeds = Yellow', 'lower_left', font='times', shadow=True)
p.add_text('Material seeds \nInternal space seeds \nSurface space seeds', 'lower_left', font='times', font_size=12, shadow=True)
p.add_text('(red) \n (black) \n (green)', 'lower_edge', font='times', font_size=10, shadow=True)
p.add_text('='+str(m1)+'\n='+str(s1)+'\n='+str(s_s1), 'lower_right', font='times', font_size=10, shadow=True)



p.subplot(0,2)
#p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color='blue', line_width=0.5, opacity=1.0, specular=1.0, render=True, lighting=True, show_scalar_bar=False, ambient=1.0)
p.add_mesh(contours2, color="white", line_width=2.0, opacity=1.0, specular=1.0, show_edges=False, edge_color='gray', smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)

p.add_text('Final Structure\nNo. of dipoles ='+y, font='times', shadow=True, color='black')
p.add_text('Packing density ='+str(g), 'lower_right', font='times', shadow=True)
#p.add_text('No. of dipoles ='+y, 'upper_right')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.set_background("grey", top="lightskyblue")
p.view_yz()
p.show()

