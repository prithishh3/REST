#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert $(awk -F ' ' '{print $2}' input.txt) rsphere
wait $!
./vtrconvert sdp_material1.out material
wait $!
./vtrconvert sdp_space1.out space
wait $!
