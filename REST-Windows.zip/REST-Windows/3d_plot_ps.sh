#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert $(awk -F ' ' '{print $6}' input.txt) rsphere
wait $!
./vtrconvert ps_material1.out material
wait $!
./vtrconvert ps_ispace1.out space
wait $!
./vtrconvert ps_sspace1.out sspace
wait $!
