import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('fma_1.vtr')
mesh4 = pv.read('fmb_1.vtr')
drags = dict(show_edges=False)

f=open("dipoles.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	print(x,y)
	

x1 = float(x)
y1 = float(y)

pack_density = y1/x1

g = float("{:.3f}".format(pack_density))

print(g)
#result.append(lines.split(' ')[1])

f=open("input.txt")

lines=f.readlines()

for z in lines:
	result=z.split(" ")
	
	r = result[0]
	m_1 = result[1]
	m_2 = result[4]

	
	#print(r,m,s)
	
r1 = int(r)*2
m1 = int(m_1)
m2 = int(m_2)

q = float("{:.3f}".format(m1/m2))

contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()
contours4 = mesh4.contour()

inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(2.0, invert=True)

pv.set_plot_theme("dark")
p = pv.Plotter(shape=(1,3), window_size=[1800,800], title="3D Plot")


p.subplot(0,0)
#p.add_mesh(mesh, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours, color="white", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Initial Structure\nNo. of dipoles ='+x, font='times', shadow=True, color='black')
p.add_text('Diameter ='+str(r1), 'lower_left', font='times', shadow=True)


p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')


p.subplot(0,1)
#p.add_mesh(mesh2, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.add_mesh(contours2, color="white", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Final Homogeneous Structure\nNo. of dipoles ='+y, font='times', shadow=True, color='black')
p.add_text('Packing density ='+str(g), 'lower_left', font='times', shadow=True)


p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.subplot(0,2)
#p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=1.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)


#p.add_mesh(mesh2, color="White", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=1.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)
#p.add_mesh(contours2, style="wireframe", render_points_as_spheres=False, color=None, scalars=None, clim=[1.0,2.0], line_width=0.5, opacity=0.5, specular=0.0, show_edges=False, edge_color='teal', smooth_shading=False, lighting=False, render=True, show_scalar_bar=True)
#p.add_mesh(contours2, style="surface", render_points_as_spheres=False, color=None, clim=contours2.get_data_range(), line_width=0.5, opacity=0.99, specular=5, show_edges=False, smooth_shading=False, lighting=False, render=True, show_scalar_bar=False)

p.add_mesh(contours3, color="white", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_mesh(contours4, color="red", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Final Inhomogeneous Structure\nNo. of dipoles ='+y, font='times', shadow=True, color='black')
p.add_text('Material1 (blue) : Material2 (green) = '+str(q), 'lower_left', font='times', shadow=True)
#p.add_text(str(q), 'lower_right', font='times', font_size=12, shadow=True)

#p.add_text('No. of dipoles ='+y, 'upper_right')

p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.set_background("grey", top="lightskyblue")
p.view_yz()
p.show()

