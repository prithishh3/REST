#!/bin/bash
echo "Calculation Started ..."
echo -ne '>                       [1%]\r'
gfortran sdp_material.f90 -o sdp_m
./sdp_m
wait $!
echo -ne '>>>>>>>>>>              [40%]\r'
gfortran sdp_space.f90 -o sdp_s
./sdp_s
wait $!
echo -ne '>>>>>>>>>>>>>>>>>       [80%]\r'
gfortran sdp_final.f90 -o sdp_f
./sdp_f
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>[100%]\r'
