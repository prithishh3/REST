import vtk
import pyvista as pv
import numpy as np
mesh = pv.read('isphere_1.vtr')
mesh2 = pv.read('rsphere_1.vtr')
mesh3 = pv.read('fma_1.vtr')
mesh4 = pv.read('fmb_1.vtr')
drags = dict(show_edges=False)

f=open("dipoles_se.in")
#for x in readlines:
lines= f.readlines()

for x in lines:
	result=x.split(" ")

	x = result[0]
	y = result[1]
	print(x,y)
	

x1 = float(x)
y1 = float(y)

pack_density = y1/x1

g = float("{:.3f}".format(pack_density))

print(g)
#result.append(lines.split(' ')[1])

f=open("shapepar.in")

lines=f.readlines()

for z in lines:
	result=z.split(" ")
	
	a = result[0]
	b = result[1]
	c = result[2]
	e = result[3]
	n = result[4]
	
#	print(a,b,c)
	
a1 = int(a)
b1 = int(b)
c1 = int(c)
e_ex = int(e)
n_ex = int(n)

	
e1 = a1/c1
e2 = b1/c1

e3 = float("{:.2}".format(e1))
e4 = float("{:.2}".format(e2))	


f=open("input.txt")

lines=f.readlines()

for z in lines:
	result=z.split(" ")
	
	#r = result[0]
	m_1 = result[0]
	m_2 = result[3]

	
	#print(r,m,s)
	
#r1 = int(r)*2
m1 = int(m_1)
m2 = int(m_2)

q = float("{:.3f}".format(m1/m2))


contours = mesh.contour()
contours2 = mesh2.contour()
contours3 = mesh3.contour()
contours4 = mesh4.contour()

inside1 = contours2.threshold(0.0)
inside2 = contours2.threshold(2.0, invert=True)

pv.set_plot_theme("dark")
p = pv.Plotter(shape=(1,3), window_size=[1800,800], title="3D Plot")


p.subplot(0,0)
p.add_mesh(mesh, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')
p.add_mesh(contours, style="surface", color="beige", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Initial Structure\nNo. of dipoles ='+x, font='times', shadow=True, color='black')
p.add_text('Semi-axes: a = '+str(a1)+', b = '+str(b1)+', c = '+str(c1)+'\nEast-west exponant e = '+str(e_ex)+'\nNorth-south exponant n = '+str(n_ex), 'lower_left', font='times', font_size=16, shadow=True)





p.subplot(0,1)
p.add_mesh(mesh, color="white", specular=1.0, opacity=0.1, show_scalar_bar=False)
p.link_views()
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')
p.add_mesh(contours2, style="surface", color="beige", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Final Homogeneous Structure\nNo. of dipoles ='+y, font='times', shadow=True, color='black')
p.add_text('Packing density ='+str(g)+'\nAspect Ratio: a/c = '+str(e3)+', b/c = '+str(e4), 'lower_left', font='times', shadow=True)


#p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')

p.subplot(0,2)
#p.add_mesh(mesh2, color="white", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=1.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)


p.add_mesh(mesh, color="White", opacity=0.1, show_scalar_bar=False, specular=1.0, lighting=True, render=True)
p.show_bounds(location='outer', show_xaxis=True, show_yaxis=True, show_zaxis=True, color='black')
#p.add_mesh(contours, color="grey", line_width=0.1, opacity=0.5, use_transparency=False, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)
#p.add_mesh(contours2, color="silver", line_width=2.0, opacity=1.0, specular=1.0, show_edges=False, smooth_shading=False, lighting=True, render=True, show_scalar_bar=False)

p.add_mesh(contours3, style='surface', color="cyan", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_mesh(contours4, style="surface", color="orchid", line_width=0.1, opacity=0.0, use_transparency=True, specular=1.0, interpolate_before_map=True, show_edges=False, edge_color='teal', smooth_shading=False, lighting=True, render=True, ambient=0.0)

p.add_text('Final Inhomogeneous Structure\nNo. of dipoles ='+y, font='times', shadow=True, color='black')
p.add_text('Material1 (cyan) : Material2 (pink) = '+str(q), 'lower_right', font='times', shadow=True)

#p.add_text('No. of dipoles ='+y, 'upper_right')




p.set_background("grey", top="lightskyblue")
p.view_xz()
p.show()

