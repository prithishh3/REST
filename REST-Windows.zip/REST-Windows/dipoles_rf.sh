#!/bin/bash
echo "$(cat target_mod.out | wc -l) $(cat target_final.out | wc -l) $(cat final.out | wc -l) $(cat combined_1.txt | wc -l)" > dipoles_rf.in
