#!/bin/bash
echo "Calculation started ..."
echo -ne '>                       [1%]\r'
gfortran sdp_material_custom.f90 -o sds_cm
./sds_cm
wait $!
echo -ne '>>>>>>>>>>              [40%]\r'
gfortran sdp_space_custom.f90 -o sds_cs
./sds_cs
wait $!
echo -ne '>>>>>>>>>>>>>>>>>       [80%]\r'
gfortran sdp_final_custom.f90 -o sds_cf
./sds_cf
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>[100%]\r'
