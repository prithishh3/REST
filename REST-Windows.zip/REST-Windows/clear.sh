#!/bin/bash
rm *.vtr *.pvd *.out shp*.dat *.txt *.dat
