#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert initial_sphere.out isphere
wait $!
./vtrconvert target_sphere.out agg
wait $!
./vtrconvert $(awk -F ' ' '{print $4}' input.txt) rsphere
wait $!
./vtrconvert agg_material1.out material
wait $!
./vtrconvert agg_space1.out space
wait $!
python3 plot_vtr_rf.py
