#!/bin/bash
echo "Calculation Started ..."
echo -ne '>                       [1%]\r'
gfortran ps_material.f90 -o ps_m
./ps_m
wait $!
echo -ne '>>>>>>>                 [30%]\r'
gfortran ps_ispace.f90 -o ps_is
./ps_is
wait $!
echo -ne '>>>>>>>>>>>>>>          [60%]\r'
gfortran ps_sspace.f90 -o ps_ss
./ps_ss
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>     [80%]\r'
gfortran ps_final.f90 -o ps_f
./ps_f
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>[100%]\r'

