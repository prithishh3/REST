#!/bin/bash
echo "Calculation Started ..."
echo -ne '>                       [1%]\r'
gfortran rough_fractal.f90 -o rf
./rf
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>     [80%]\r'
gfortran rough_fractal_surface.f90 -o rfs
./rfs
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>   [90%]\r'
gfortran rms.f90 -o rms
./rms
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>[100%]\r'
