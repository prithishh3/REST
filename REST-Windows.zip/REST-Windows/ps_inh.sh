#!/bin/bash
echo "Calculation started ..."
echo -ne '>                       [1%]\r'
gfortran ps_inh_material.f90 -o ps_inhm
./ps_inhm
wait $!
echo -ne '>>                      [5%]\r'
gfortran ps_inh_ispace.f90 -o ps_inhis
./ps_inhis
wait $!
echo -ne '>>>>>                   [15%]\r'
gfortran ps_inh_sspace.f90 -o ps_inhss
./ps_inhss
wait $!
echo -ne '>>>>>>>>>               [30%]\r'
gfortran ps_inh_final2.f90 -o ps_inhf2
./ps_inhf2
wait $!
echo -ne '>>>>>>>>>>>>>           [50%]\r'
gfortran ps_inh_material1.f90 -o ps_inhm1
./ps_inhm1
wait $!
echo -ne '>>>>>>>>>>>>>>>>>       [70%]\r'
gfortran ps_inh_material2.f90 -o ps_inhm2
./ps_inhm2
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>   [90%]\r'
gfortran ps_inh_mix.f90 -o ps_mix
./ps_mix
wait $!
echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>[100%]\r'
