#!/bin/bash
chmod +x vtrconvert
wait $!
./vtrconvert $(awk -F ' ' '{print $4}' input.txt) rsphere
wait $!
python3 plot_vtr_cs2.py
